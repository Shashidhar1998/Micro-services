package com.onlineshopping.outletservice.responses.outlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeRegisterRes {
    private String token;
    private String username;
}
