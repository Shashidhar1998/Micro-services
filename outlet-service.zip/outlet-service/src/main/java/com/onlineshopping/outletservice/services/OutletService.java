package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.repositories.OutletRepository;
import com.onlineshopping.outletservice.requests.outlet.OutletRegisterRequest;
import com.onlineshopping.outletservice.utils.OutletUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OutletService {

    @Autowired
    OutletRepository outletrepository;

    @Autowired
    OutletUtil outletutil;
    public Outlet createOutlet(OutletRegisterRequest outletObj) {
        String shopId = "";
        Boolean exitloop = false;
        while(!exitloop){
            shopId = outletutil.createShopId(outletObj.getName());
            Optional<Outlet> outletidExists = findOutletByName(shopId);
            if(!outletidExists.isPresent()){
                exitloop = true;
            }
        }
        Outlet outlet = new Outlet(shopId, outletObj.getName(), outletObj.getType(), outletObj.getAddress(), outletObj.getCity(), outletObj.getState(), outletObj.getPincode(), outletObj.getGst(), outletObj.getOwnerName(), outletObj.getOwnerMail(), outletObj.getOwnerMobile());
        return outletrepository.save(outlet);
    }


    public List<Outlet> getAllOutlets() {
        return outletrepository.findAll();
    }

    public Outlet getOutletById(Long outlet_id) {
        return outletrepository.getById(outlet_id);
    }

    public Optional<Outlet> findOutletById(Long outlet_id) {
        return outletrepository.findById(outlet_id);
    }

    public Optional<Outlet> findOutletByName(String outlet_name) {
        return outletrepository.findByShopId(outlet_name);
    }
}
