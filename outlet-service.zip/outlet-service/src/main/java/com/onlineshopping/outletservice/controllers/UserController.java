package com.onlineshopping.outletservice.controllers;


import com.onlineshopping.outletservice.models.User;
import com.onlineshopping.outletservice.models.UserRole;
import com.onlineshopping.outletservice.models.UserRoleName;
import com.onlineshopping.outletservice.repositories.UserRepository;
import com.onlineshopping.outletservice.repositories.UserRoleRepository;
import com.onlineshopping.outletservice.requests.user.CreateUser;
import com.onlineshopping.outletservice.requests.user.UserAuthRequest;
import com.onlineshopping.outletservice.services.UserPrinciple;
import com.onlineshopping.outletservice.utils.JwtProvider;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;


import org.slf4j.Logger;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@RestController
@CrossOrigin(origins = "*")
public class UserController {

    Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtProvider jwtProvider;

    @PostMapping("/createuser")
    public User createEmployee(@RequestBody CreateUser obj ){
        User user = new User(obj.getFirstName(),obj.getLastName(),obj.getMail(),encoder.encode(obj.getPassword()));

        Set<String> strRoles = obj.getRoles();
        Set<UserRole> roles = new HashSet<>();

        if(strRoles.contains("owner")){
            Optional<UserRole> ownerRole = userRoleRepository.findByName(UserRoleName.ROLE_OWNER);
            if(ownerRole.isPresent()){
                roles.add(ownerRole.get());
            }
        }
        else if(strRoles.contains("user")){
            UserRole userRole = userRoleRepository.findByName(UserRoleName.ROLE_USER)
                    .orElseThrow(() -> new RuntimeException("Issue with role :" + UserRoleName.ROLE_USER));
            roles.add(userRole);
        }
        user.setRoles(roles);
        return userRepository.save(user);
    }

    @PostMapping("/signin")
    public ResponseEntity<?> Authenticate(@RequestBody UserAuthRequest authenticationRequest) throws Exception{
        try {
            String username = authenticationRequest.getUsername();
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username,authenticationRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);

            String token = jwtProvider.generateJwtToken(authentication);
            UserPrinciple employeePrinciple = (UserPrinciple) authentication.getPrincipal();
           return (ResponseEntity<?>) ResponseEntity.ok(token);
        }
        catch(BadCredentialsException e) {
            throw new Exception("Incorrect Username or Password Exception",e);
        }
        catch(Exception e) {
            throw new Exception("Something Went Wrong",e);
        }
    }

    @GetMapping("/public/users")
    public ResponseEntity<?> getEmployees(){
        logger.info("Info");
        return ResponseEntity.ok(userRepository.findAll());
    }
}
