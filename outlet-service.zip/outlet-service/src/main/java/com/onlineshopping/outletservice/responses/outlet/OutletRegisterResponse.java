package com.onlineshopping.outletservice.responses.outlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OutletRegisterResponse {
    private String ShopId;
    private String message;
    private String status_code;

}
