package com.onlineshopping.outletservice.models;

public enum UserRoleName {
    ROLE_USER,
    ROLE_OWNER
}
