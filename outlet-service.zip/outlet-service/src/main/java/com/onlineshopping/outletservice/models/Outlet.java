package com.onlineshopping.outletservice.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;


@Entity
@Table(name = "outlet")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Outlet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "shop_id",unique = true)
    private String shopId;

    @Column(name = "shop_name")
    private String name;

    @JsonManagedReference
    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(
            name = "shop_categories",
            joinColumns = @JoinColumn(name = "outlet_id"),
            inverseJoinColumns = @JoinColumn(name = "category_id"))
    private List<Category> categories = new ArrayList<>();

    @Column(name = "shop_type")
    private OutletType type;

    @Column(name = "shop_address")
    private String address;

    @Column(name = "shop_city")
    private String city;

    @Column(name = "shop_state")
    private String state;

    @Column(name = "shop_pincode")
    private String pincode;

    @Column(name = "shop_gst",unique = true)
    private String gst;

    @Column(name = "shop_owner_name")
    private String ownerName;

    @Column(name = "shop_owner_mail",unique = true)
    @Pattern(regexp="(^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$)")
    private String ownerMail;

    @Column(name = "shop_owner_mobile",unique = true)
    @Pattern(regexp="(^$|[0-9]{10})")
    private String ownerMobile;

    @Column(name = "timestamp")
    @CreationTimestamp
    private Date timestamp;

    @Column(name = "last_updated")
    @UpdateTimestamp
    private Date lastUpdated;



    public Outlet(String shopId,String name, OutletType type, String address, String city, String state, String pincode, String gst, String ownerName, String ownerMail, String ownerMobile) {
        this.shopId = shopId;
        this.name = name;
        this.type = type;
        this.address = address;
        this.city = city;
        this.state = state;
        this.pincode = pincode;
        this.gst = gst;
        this.ownerName = ownerName;
        this.ownerMail = ownerMail;
        this.ownerMobile = ownerMobile;
    }


}
