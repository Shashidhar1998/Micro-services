package com.onlineshopping.outletservice.responses.category;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoryRegisterResponse {
    private Long ShopId;
    private String Category;
}
