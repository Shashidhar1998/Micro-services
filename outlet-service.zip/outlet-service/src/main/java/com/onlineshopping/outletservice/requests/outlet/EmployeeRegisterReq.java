package com.onlineshopping.outletservice.requests.outlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EmployeeRegisterReq {
    private String username;
    private String mobileNumber;
    private String password;
    private Set<String> roles;
}
