package com.onlineshopping.outletservice.responses.outlet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmployeeAuthResponse {

   private static String tokenType = "Bearer ";
   private String token;
   private String roles;
   private String shopId;

}
