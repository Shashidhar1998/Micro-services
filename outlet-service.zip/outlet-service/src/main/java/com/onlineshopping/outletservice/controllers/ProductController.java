package com.onlineshopping.outletservice.controllers;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.Product;
import com.onlineshopping.outletservice.requests.product.ProductCreateRequest;
import com.onlineshopping.outletservice.services.OutletService;
import com.onlineshopping.outletservice.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.security.auth.Subject;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
public class ProductController {

    @Autowired
    ProductService productservice;

    @Autowired
    OutletService outletservice;

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productservice.getAllOutlets();
    }

    @GetMapping("/products/id/{product_id}")
    public Optional<Product> getProductById(@PathVariable Long product_id){
        return productservice.findProductById(product_id);
    }

    @PostMapping("/createproduct")
    public Product createProduct(@RequestBody ProductCreateRequest productObj) {
        return productservice.createProduct(productObj);
    }

}
