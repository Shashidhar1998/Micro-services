package com.onlineshopping.outletservice.requests.outlet;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.OutletType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OutletRegisterRequest {

    private String name;
    private OutletType type;
    private String address;
    private String city;
    private String state;
    private String pincode;
    private String gst;
    private String ownerName;
    private String ownerMail;
    private String ownerMobile;


}
