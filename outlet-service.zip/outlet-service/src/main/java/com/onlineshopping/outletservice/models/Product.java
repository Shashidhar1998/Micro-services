package com.onlineshopping.outletservice.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "product")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String description;
    private String company;
    private Long price;
    @Column(columnDefinition = "integer default 0")
    private Long discount;

    @JsonBackReference
    @ManyToMany(mappedBy = "products",fetch = FetchType.LAZY)
    private List<Category> categories = new ArrayList<>();
    public Product(String name, String description, String company, Long price, Long discount) {
        this.name = name;
        this.description = description;
        this.company = company;
        this.price = price;
        this.discount = discount;
    }
}
