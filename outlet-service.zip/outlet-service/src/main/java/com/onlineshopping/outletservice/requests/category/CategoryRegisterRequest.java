package com.onlineshopping.outletservice.requests.category;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CategoryRegisterRequest {
    private  Long shopId;
    private  String categoryName;

}
