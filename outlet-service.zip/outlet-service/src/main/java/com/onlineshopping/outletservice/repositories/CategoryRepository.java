package com.onlineshopping.outletservice.repositories;

import com.onlineshopping.outletservice.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository   extends JpaRepository<Category, Long> {
}
