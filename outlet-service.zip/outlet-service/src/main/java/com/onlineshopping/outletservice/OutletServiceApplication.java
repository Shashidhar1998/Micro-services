package com.onlineshopping.outletservice;

import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class OutletServiceApplication implements CommandLineRunner {

	@Autowired
	OutletEmployeeRoleRepository roleRepository;
	public static void main(String[] args) {
		SpringApplication.run(OutletServiceApplication.class, args);
	}

	@Override
	public void run(String... args) {
		if(!(roleRepository.findByName(OutletEmployeeRoleName.ROLE_EMPLOYEE).isPresent() && roleRepository.findByName(OutletEmployeeRoleName.ROLE_OWNER).isPresent())){
			OutletEmployeeRole role1 = new OutletEmployeeRole(OutletEmployeeRoleName.ROLE_EMPLOYEE);
			OutletEmployeeRole role2 = new OutletEmployeeRole(OutletEmployeeRoleName.ROLE_OWNER);
			roleRepository.save(role1);
			roleRepository.save(role2);
			System.out.println("Roles Added");
		}
		else{
			System.out.println("Application Started");
		}

	}

}
