package com.onlineshopping.outletservice;

import com.onlineshopping.outletservice.models.UserRole;
import com.onlineshopping.outletservice.models.UserRoleName;
import com.onlineshopping.outletservice.repositories.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class OutletServiceApplication implements CommandLineRunner {

	@Autowired
	UserRoleRepository roleRepository;
	public static void main(String[] args) {
		SpringApplication.run(OutletServiceApplication.class, args);
	}

	@Override
	public void run(String... args) {
		if(!(roleRepository.findByName(UserRoleName.ROLE_USER).isPresent() && roleRepository.findByName(UserRoleName.ROLE_OWNER).isPresent())){
			UserRole role1 = new UserRole(UserRoleName.ROLE_OWNER);
			UserRole role2 = new UserRole(UserRoleName.ROLE_USER);
			roleRepository.save(role1);
			roleRepository.save(role2);
		}

	}

}
