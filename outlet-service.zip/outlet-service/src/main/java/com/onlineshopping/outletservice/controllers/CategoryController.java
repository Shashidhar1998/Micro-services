package com.onlineshopping.outletservice.controllers;

import com.onlineshopping.outletservice.models.Category;
import com.onlineshopping.outletservice.requests.category.CategoryRegisterRequest;
import com.onlineshopping.outletservice.responses.category.CategoryRegisterResponse;
import com.onlineshopping.outletservice.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
public class CategoryController {
    @Autowired
    CategoryService categoryservice;

    @PostMapping("/createcategory")
    public CategoryRegisterResponse createCategory(@RequestBody CategoryRegisterRequest categoryObj){
        Category category = categoryservice.createCategory(categoryObj);
        return new CategoryRegisterResponse(categoryObj.getShopId(),category.getCategoryName());
    }
}
