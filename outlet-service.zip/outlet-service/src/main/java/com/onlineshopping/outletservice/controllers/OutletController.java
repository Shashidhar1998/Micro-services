package com.onlineshopping.outletservice.controllers;

import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import com.onlineshopping.outletservice.requests.outlet.OutletRegisterRequest;
import com.onlineshopping.outletservice.responses.outlet.OutletRegisterResponse;
import com.onlineshopping.outletservice.services.EmployeeDetailsServiceImpl;
import com.onlineshopping.outletservice.services.OutletService;
import com.onlineshopping.outletservice.services.mail.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.ConstraintViolationException;
import java.util.*;

@CrossOrigin(origins = "*")
@RestController
public class OutletController {

    @Autowired
    OutletService outletservice;


    @Autowired
    EmployeeDetailsServiceImpl employeeDetailsService;

    @Autowired
    EmailService emailService;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    PasswordEncoder passwordEncoder;
    @GetMapping("/outletslist")
    public List<Outlet> getAllOutlets() {
        return outletservice.getAllOutlets();
    }

    @GetMapping("/outlets/id/{outlet_id}")
    public Optional<Outlet> getOutletById(@PathVariable Long outlet_id){
        return outletservice.findOutletById(outlet_id);
    }
    @GetMapping("/outlets/shop-id/{outlet_name}")
    public Optional<Outlet> getOutletByName(@PathVariable String outlet_name){
        return outletservice.findOutletByName(outlet_name);
    }
    @PostMapping("/createoutlet")
    public ResponseEntity<Object> createOutlet(@RequestBody OutletRegisterRequest outletreq) {
        HttpHeaders headers = new HttpHeaders();
        try {
            headers.add("Custom-Header", "Outlet Created");
            Outlet outlet = outletservice.createOutlet(outletreq);
            try{
            OutletEmployee employee = new OutletEmployee(outletreq.getOwnerMail(),outletreq.getOwnerMail(),outletreq.getOwnerMobile(),encoder.encode(outlet.getShopId()));
            Boolean isSaved = employeeDetailsService.saveOwnerAsEmployee(employee);
            if(isSaved){
                String message = "Username : " + employee.getUsername() +  "\n Password : " + outlet.getShopId();
                OutletRegisterResponse outletRegisterResponse = new OutletRegisterResponse(outlet.getShopId(),message,"200");
                emailService.sendTemplateEmail(employee,outlet.getShopId());
                return new ResponseEntity<Object>(outletRegisterResponse,headers, HttpStatus.CREATED);
            }}catch (Exception e){
                return new ResponseEntity<Object>("Error while creating owner", headers, HttpStatus.BAD_REQUEST);
            }
        }
        catch(DataIntegrityViolationException e) {
            headers.add("Custom-Header", "foo");
            return new ResponseEntity<Object>("Shop Id Should be Unique", headers, HttpStatus.BAD_REQUEST);
        }
        catch(ConstraintViolationException e){
            headers.add("Custom-Header", "foo");
            return new ResponseEntity<Object>("Please check Mobile Number/Email", headers, HttpStatus.BAD_REQUEST);
        }
        return  new ResponseEntity<Object>("Something went wrong ", headers, HttpStatus.BAD_REQUEST);
    }
}
