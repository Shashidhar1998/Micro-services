package com.onlineshopping.outletservice.models;


import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "outlet_role")
public class OutletEmployeeRole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private OutletEmployeeRoleName name;

    public OutletEmployeeRole() {
    }

    public OutletEmployeeRole(OutletEmployeeRoleName name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OutletEmployeeRoleName getName() {
        return name;
    }

    public void setName(OutletEmployeeRoleName name) {
        this.name = name;
    }
}
