package com.onlineshopping.outletservice.models;

public class OutletId {


}
