package com.onlineshopping.outletservice.services;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.onlineshopping.outletservice.models.OutletEmployee;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


public class EmployeePrinciple implements UserDetails{

    private Long id;
    private String username;
    private String mail;
    private String mobileNumber;
    @JsonIgnore
    private String password;

    private Collection<? extends GrantedAuthority> authorities ;
    public EmployeePrinciple(Long id, String username ,String mail, String mobileNumber, String password,Collection<? extends GrantedAuthority> authorities){
        this.id = id;
        this.username = username;
        this.mail = mail;
        this.mobileNumber = mobileNumber;
        this.password = password;
        this.authorities = authorities;
    }

    public static EmployeePrinciple build(OutletEmployee user) {
        List<GrantedAuthority> authorities = user.getRoles().stream().map(role -> new SimpleGrantedAuthority(role.getName().name())).collect(Collectors.toList());

        return new EmployeePrinciple(user.getId(),user.getUsername(),user.getMail(), user.getMobileNumber(),user.getPassword(), authorities);

    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public String getMail() {
        return mail;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }


    @Override
    public String getPassword() {
        return password;
    }


    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;

        EmployeePrinciple user = (EmployeePrinciple) o;
        return Objects.equals(id,user.id);
    }


}
