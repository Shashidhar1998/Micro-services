package com.onlineshopping.outletservice.services;

import com.onlineshopping.outletservice.models.Category;
import com.onlineshopping.outletservice.models.Outlet;
import com.onlineshopping.outletservice.models.Product;
import com.onlineshopping.outletservice.repositories.CategoryRepository;
import com.onlineshopping.outletservice.repositories.OutletRepository;
import com.onlineshopping.outletservice.requests.category.CategoryRegisterRequest;
import com.onlineshopping.outletservice.responses.category.CategoryRegisterResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    OutletRepository outletRepository;
    public Category createCategory(CategoryRegisterRequest categoryObj) {
        Outlet outlet = outletRepository.getById(categoryObj.getShopId());
        Category category = new Category();
        category.setCategoryName(categoryObj.getCategoryName());
        List<Category> categories = outlet.getCategories();
        categories.add(category);
        outlet.setCategories(categories);
        outletRepository.save(outlet);
        return category;
    }
}


