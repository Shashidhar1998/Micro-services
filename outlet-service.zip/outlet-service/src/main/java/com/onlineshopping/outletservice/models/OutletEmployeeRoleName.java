package com.onlineshopping.outletservice.models;

public enum OutletEmployeeRoleName {
    ROLE_EMPLOYEE,
    ROLE_OWNER
}
