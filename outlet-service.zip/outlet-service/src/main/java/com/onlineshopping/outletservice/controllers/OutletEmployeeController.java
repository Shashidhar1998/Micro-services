package com.onlineshopping.outletservice.controllers;


import com.onlineshopping.outletservice.config.JwtProvider;
import com.onlineshopping.outletservice.models.OutletEmployee;
import com.onlineshopping.outletservice.models.OutletEmployeeRole;
import com.onlineshopping.outletservice.models.OutletEmployeeRoleName;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRepository;
import com.onlineshopping.outletservice.repositories.OutletEmployeeRoleRepository;
import com.onlineshopping.outletservice.requests.outlet.EmployeeRegisterReq;
import com.onlineshopping.outletservice.requests.outlet.OutletRegisterRequest;
import com.onlineshopping.outletservice.requests.shopadmin.OutletAuthRequest;
import com.onlineshopping.outletservice.responses.outlet.EmployeeRegisterRes;
import com.onlineshopping.outletservice.services.EmployeeDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.Set;

@RestController
@CrossOrigin(origins = "*")
public class OutletEmployeeController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    PasswordEncoder encoder;


    @Autowired
    EmployeeDetailsServiceImpl employeeDetailsService;

    @Autowired
    OutletEmployeeRoleRepository roleRepository;

    @Autowired
    OutletEmployeeRepository employeeRepository;

    @Autowired
    JwtProvider jwtProvider;
    @PostMapping("/createemployee")
    public OutletEmployee createEmployee(@RequestBody EmployeeRegisterReq obj ){
        OutletEmployee employee = new OutletEmployee(obj.getUsername(),obj.getUsername(),obj.getMobileNumber(),encoder.encode(obj.getPassword()));

        Set<String> strRoles = obj.getRoles();
        Set<OutletEmployeeRole> roles = new HashSet<>();

        strRoles.forEach( role ->{
            switch (role){
                case "owner" :
                    OutletEmployeeRole ownerrole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_OWNER)
                        .orElseThrow(() -> new RuntimeException("Issue with role"));
                    roles.add(ownerrole);

                    break;
                case "employee" :
                    OutletEmployeeRole employeerole = roleRepository.findByName(OutletEmployeeRoleName.ROLE_EMPLOYEE)
                            .orElseThrow(() -> new RuntimeException("Issue with role"));
                    roles.add(employeerole);
                    break;
            }});
        employee.setRoles(roles);
        return employeeRepository.save(employee);
    }
    @PostMapping("/signin")
    public ResponseEntity<?> Authenticate(@RequestBody OutletAuthRequest authenticationRequest) throws Exception{
        try {
            String username = authenticationRequest.getUsername();
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username,authenticationRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);

            String token = jwtProvider.generateJwtToken(authentication);
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();

            return ResponseEntity.ok(new EmployeeRegisterRes(token,userDetails.getUsername()));

        }
        catch(BadCredentialsException e) {
            throw new Exception("Incorrect Username or Password Exception",e);
        }
        catch(Exception e) {
            throw new Exception("Something Went Wrong",e);
        }
    }
}
