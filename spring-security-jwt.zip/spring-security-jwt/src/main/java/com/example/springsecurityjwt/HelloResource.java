package com.example.springsecurityjwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.springsecurityjwt.models.AuthenticationRequest;
import com.example.springsecurityjwt.models.AuthenticationResponse;
import com.example.springsecurityjwt.services.MyUserDetailsService;
import com.example.springsecurityjwt.util.JwtUtil;



@CrossOrigin(origins = "*")
@RestController
public class HelloResource {

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private MyUserDetailsService myuserDetailsService;
	
	@Autowired
	private JwtUtil jwtutil;
	
	@GetMapping("/hello")
	public String hello() {
		
		return "Hello World";
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> Authenticate(@RequestBody AuthenticationRequest authenticationRequest) throws Exception{
		try {
		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(),authenticationRequest.getPassword()));
		}
		catch(BadCredentialsException e) {
			throw new Exception("Incorrect Username or Password",e);
		}
		
		final UserDetails userdetails = myuserDetailsService.loadUserByUsername(authenticationRequest.getUsername());
		if(userdetails != null && userdetails.getUsername().equals(authenticationRequest.getUsername())) {
			System.out.println(authenticationRequest.getUsername());
			final String jwt = jwtutil.generateToken(userdetails);
			return ResponseEntity.ok(new AuthenticationResponse(jwt));
		}
		else {
			HttpHeaders headers = new HttpHeaders();
		    headers.add("Custom-Header", "foo");
		    return new ResponseEntity<>("Incorrect Username or Password", headers, HttpStatus.BAD_REQUEST);
		}
	}
}
