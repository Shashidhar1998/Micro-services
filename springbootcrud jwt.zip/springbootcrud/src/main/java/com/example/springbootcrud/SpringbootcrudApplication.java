package com.example.springbootcrud;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

import com.example.springbootcrud.models.Role;
import com.example.springbootcrud.models.RoleName;
import com.example.springbootcrud.models.Student;
import com.example.springbootcrud.models.Subject;
import com.example.springbootcrud.repositories.RoleRepository;
import com.example.springbootcrud.repositories.StudentRepository;
import com.example.springbootcrud.repositories.SubjectRepository;

@SpringBootApplication
public class SpringbootcrudApplication implements CommandLineRunner{
	  
	  @Autowired
	  StudentRepository studentRepository;
	  
	  @Autowired
	  SubjectRepository subjectRepository;
	  
	  @Autowired
	  RoleRepository rolerepository;
	 
	  public static void main(String[] args) {
	    SpringApplication.run(SpringbootcrudApplication.class, args);
	  }
	 
	  @Transactional
	  @Override
	  public void run(String... arg0) throws Exception {
	    
	    // delete all tables

		studentRepository.deleteAll();
//		rolerepository.deleteAll();
		//subjectRepository.deleteAll();
        Student jack = new Student("Jack");
        Student peter = new Student("Peter");
    
        Subject math = new Subject("Mathematics");
	    Subject computer = new Subject("Compter");
	    
	    Set<Subject> subjects = new HashSet<Subject>();
	    subjects.add(math);
	    subjects.add(computer);
	    
	    jack.setSubjects(subjects);
	    peter.setSubjects(subjects);
	    
	    studentRepository.save(jack);
	    studentRepository.save(peter);
	    
	    
//	    Role adminrole = new Role();
//	    adminrole.setName(RoleName.ROLE_USER);
//	    rolerepository.save(adminrole);
//	    Role pmrole = new Role();
//	    pmrole.setName(RoleName.ROLE_PM);
//	    rolerepository.save(pmrole);
//	    Role userrole = new Role();
//	    userrole.setName(RoleName.ROLE_ADMIN);
//	    rolerepository.save(userrole);
//	    Set<Student> students = new HashSet<Student>();
//	    students.add(jack);
//	    students.add(peter);
//	    math.setStudents(students);
//	    computer.setStudents(students);
//	    
//	    subjectRepository.save(math);
//	    subjectRepository.save(computer);
	  }
	}

