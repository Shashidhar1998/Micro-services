package com.example.springbootcrud.repositories;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.springbootcrud.models.Subject;


@Repository
public interface SubjectRepository extends PagingAndSortingRepository<Subject, Integer> {
}