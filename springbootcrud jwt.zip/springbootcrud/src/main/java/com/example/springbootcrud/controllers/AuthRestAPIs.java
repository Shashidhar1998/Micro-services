package com.example.springbootcrud.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.springbootcrud.filters.JwtProvider;
import com.example.springbootcrud.models.Role;
import com.example.springbootcrud.models.RoleName;
import com.example.springbootcrud.models.User;
import com.example.springbootcrud.repositories.RoleRepository;
import com.example.springbootcrud.requests.LoginForm;
import com.example.springbootcrud.requests.SignUpForm;
import com.example.springbootcrud.response.JwtResponse;
import com.example.springbootcrud.response.ResponseMessage;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/home")
public class AuthRestAPIs extends Thread{

	
	
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	com.example.springbootcrud.repositories.userRepository userRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtProvider jwtProvider;

	public void run(){  
		System.out.println("thread is running...");  
		} 
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginForm loginRequest) {

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);
		String jwt = jwtProvider.generateJwtToken(authentication);
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		//check if this account is confirmed, ccode will be empty if 
		//user account is confirmed
		List<User> lu = userRepository.findUsernameCCode(loginRequest.getUsername(), "");
		
		if(lu.size()>0)
		{
			return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(), userDetails.getAuthorities()));
		}
		else
		{
			return ResponseEntity.ok("{status: \"Confirmation Pending\"}");
		}
	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpForm signUpRequest) {
		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Username is already taken!"),
					HttpStatus.BAD_REQUEST);
		}

		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity<>(new ResponseMessage("Fail -> Email is already in use!"),
					HttpStatus.BAD_REQUEST);
		}

		//generate random confirm code of atleast 6 characters
		String ccode = "11111111";
		
		// Creating user's account
		User user = new User(signUpRequest.getName(), ccode, signUpRequest.getUsername(), signUpRequest.getEmail(),
				encoder.encode(signUpRequest.getPassword()));

		Set<String> strRoles = signUpRequest.getRole();
		Set<Role> roles = new HashSet<>();

		strRoles.forEach(role -> {
			switch (role) {
			case "admin":
				Role adminRole = roleRepository.findByName(RoleName.ROLE_ADMIN)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(adminRole);

				break;
			case "pm":
				Role pmRole = roleRepository.findByName(RoleName.ROLE_PM)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(pmRole);

				break;
			default:
				Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
						.orElseThrow(() -> new RuntimeException("Fail! -> Cause: User Role not find."));
				roles.add(userRole);
			}
		});

		user.setRoles(roles);
		userRepository.save(user);
		 
		return new ResponseEntity<>(new ResponseMessage("User registered successfully!"), HttpStatus.OK);
	}
	
	//HTTP GET 
	@RequestMapping(value="user", method = RequestMethod.GET)
	public ResponseEntity<?> confirmSignup(@RequestParam("ccode") String ccode, 
			@RequestParam("username") String username
			){
		//validate if ccode and username confirms
		List<User> lu = userRepository.findUsernameCCode(username, ccode);
	
		//if match return confirmed
		if(lu.size()>0) //check if condition need to be improved
		{
			//Update ccode to empty in database
			userRepository.updateCCode(username);
			return new ResponseEntity<>(new ResponseMessage("User registered successfully!"), HttpStatus.OK);
		}
		else //else return could not confirm
		{
			return new ResponseEntity<>(new ResponseMessage("Error and UnAuthorized"), HttpStatus.UNAUTHORIZED);
		}
	}
}