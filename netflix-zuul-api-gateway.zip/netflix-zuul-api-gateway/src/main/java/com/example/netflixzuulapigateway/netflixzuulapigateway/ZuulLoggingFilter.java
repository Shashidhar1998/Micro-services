package com.example.netflixzuulapigateway.netflixzuulapigateway;

import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;  
import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;   
import com.netflix.zuul.ZuulFilter;  
import com.netflix.zuul.context.RequestContext;  
import com.netflix.zuul.exception.ZuulException;  

@Component
public class ZuulLoggingFilter extends ZuulFilter{

	private Logger logger =LoggerFactory.getLogger(this.getClass());  
	
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "pre";
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 1;
	}

	public Object run() throws ZuulException  
	{  
	//getting the current HTTP request that is to be handle  
	HttpServletRequest request=RequestContext.getCurrentContext().getRequest();  
	//printing the detail of the request  
	logger.info("request -> {} request uri-> {}", request, request.getRequestURI());  
	return null;  
	}  
}
