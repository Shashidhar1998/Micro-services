package com.example.microservices.springbootdemo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableDiscoveryClient
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class SpringBootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoApplication.class, args);
	}

	@GetMapping("/stringlist")
	public List<String> getlist(){
		List<String> stringlist = new ArrayList<String>();
		stringlist.add("Shashidhar");
		stringlist.add("Bharath");
		return stringlist;
	}
}
