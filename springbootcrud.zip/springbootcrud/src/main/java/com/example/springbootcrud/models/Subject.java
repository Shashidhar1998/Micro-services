package com.example.springbootcrud.models;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
 
@Entity
public class Subject {
  
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
  private int id;
  private String name;
  
  @ManyToMany(mappedBy = "subjects", fetch = FetchType.EAGER)
  @JsonBackReference
  private Set<Student> students = new HashSet<>();
  
    public Subject(){
    }
    
    public Subject(String name){
      this.name = name;
    }
    
    public Subject(String name, Set<Student> students){
      this.name = name;
      this.students = students;
    }
  
  // name
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
  // students
  public Set<Student> getStudents() {
    return students;
  }
  
  public void setStudents(Set<Student> students) {
    this.students = students;
  }
}
